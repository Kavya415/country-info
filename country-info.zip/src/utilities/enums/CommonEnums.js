const commonEnums = {
    LIGHT_MODE: 0,
    DARK_MODE: 1,
    PRODUCT_LISTING: 2,
    PRODUCT_DETAIL: 3,
    NO_BORDERS_TEXT: "No Bordering Countries"
}

export default commonEnums;